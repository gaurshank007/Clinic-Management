﻿namespace ClinicManagement.Core.Models
{
    public class City
    {
        public byte Id { get; set; }
        public string Name { get; set; }
    }
}