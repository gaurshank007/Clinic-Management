﻿namespace ClinicManagement.Core.Dto
{
    public class SpecializationDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}